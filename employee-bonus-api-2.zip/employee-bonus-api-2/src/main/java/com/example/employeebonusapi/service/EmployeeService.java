package com.example.employeebonusapi.service;




import java.time.LocalDate;
import java.util.List;

import com.example.employeebonusapi.dto.EmployeeBonusDTO;
import com.example.employeebonusapi.entity.Employee;


public interface EmployeeService {
	public void saveEmployees(List<Employee> employees);
	 List<EmployeeBonusDTO> getEmployeeBonus(String date);
	

}
