package com.example.employeebonusapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeBonusApi2Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeBonusApi2Application.class, args);
	}

}
