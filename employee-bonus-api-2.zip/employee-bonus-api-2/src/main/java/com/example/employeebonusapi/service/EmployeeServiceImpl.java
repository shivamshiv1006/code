package com.example.employeebonusapi.service;

import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.employeebonusapi.dto.EmployeeBonusDTO;
import com.example.employeebonusapi.dto.EmployeeDetailDTO;
import com.example.employeebonusapi.entity.Employee;
import com.example.employeebonusapi.exception.DatabaseOperationException;
import com.example.employeebonusapi.exception.DateParseException;
import com.example.employeebonusapi.repository.EmployeeRepository;
import java.text.ParseException;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepository;

	  @Override
	    public void saveEmployees(List<Employee> employees) {
	        try {
	            employeeRepository.saveAll(employees);
	        } catch (Exception e) {
	            throw new DatabaseOperationException("Failed to save employees", e);
	        }
	    }

	  @Override
	    public List<EmployeeBonusDTO> getEmployeeBonus(String date) {
	        // Implement the logic to fetch employees based on the date
	        // For demonstration, returning a sample response
	        List<EmployeeBonusDTO> bonusDTOList = new ArrayList<>();

	        List<EmployeeDetailDTO> inrEmployees = new ArrayList<>();
	        inrEmployees.add(new EmployeeDetailDTO("pratap m", 3000));
	        inrEmployees.add(new EmployeeDetailDTO("raj singh", 5000));
	        bonusDTOList.add(new EmployeeBonusDTO("INR", inrEmployees));

	        List<EmployeeDetailDTO> usdEmployees = new ArrayList<>();
	        usdEmployees.add(new EmployeeDetailDTO("sam", 2500));
	        usdEmployees.add(new EmployeeDetailDTO("susan", 700));
	        bonusDTOList.add(new EmployeeBonusDTO("USD", usdEmployees));

	        return bonusDTOList;
	    }
}
