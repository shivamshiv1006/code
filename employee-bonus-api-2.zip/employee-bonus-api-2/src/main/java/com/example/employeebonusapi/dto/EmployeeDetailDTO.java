package com.example.employeebonusapi.dto;

public class EmployeeDetailDTO {
	
	private String empName;
    private double amount;
	public EmployeeDetailDTO(String empName, double amount) {
		super();
		this.empName = empName;
		this.amount = amount;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}

}
