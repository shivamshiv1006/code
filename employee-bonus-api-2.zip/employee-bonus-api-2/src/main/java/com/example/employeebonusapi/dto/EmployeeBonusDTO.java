package com.example.employeebonusapi.dto;

import java.util.List;

public class EmployeeBonusDTO {
	private String currency;
	private List<EmployeeDetailDTO> employees;
	public EmployeeBonusDTO(String currency, List<EmployeeDetailDTO> employees) {
		super();
		this.currency = currency;
		this.employees = employees;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public List<EmployeeDetailDTO> getEmployees() {
		return employees;
	}
	public void setEmployees(List<EmployeeDetailDTO> employees) {
		this.employees = employees;
	}
	
	
	
}