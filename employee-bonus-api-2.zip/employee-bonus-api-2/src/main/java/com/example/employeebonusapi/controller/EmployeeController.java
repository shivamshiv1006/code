package com.example.employeebonusapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.employeebonusapi.dto.EmployeeBonusDTO;
import com.example.employeebonusapi.entity.Employee;
import com.example.employeebonusapi.exception.DateParseException;
import com.example.employeebonusapi.service.EmployeeService;

@RestController
@RequestMapping("/tci")
public class EmployeeController {
    
    @Autowired
    private EmployeeService employeeService;
    
    @PostMapping("/employee-bonus")
    public ResponseEntity<String> saveEmployees(@RequestBody List<Employee> request) {
        System.out.println("Received JSON data from POST request: " + request);
        try {
            // Log the JSON data received from the POST request
            System.out.println("Received JSON data from POST request: " + request);
            System.out.println("Employee Data: " + request);
            // Save employees
            employeeService.saveEmployees(request);
            System.out.println("Employees saved successfully " + request.toString());
            return ResponseEntity.status(HttpStatus.CREATED).body("Employees saved successfully");
        } catch (DateParseException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to save employees");
        }
    }
    
    @GetMapping("/employee-bonus")
    public ResponseEntity<List<EmployeeBonusDTO>> getEmployeeBonus(@RequestParam("date") String date) {
        List<EmployeeBonusDTO> bonusDTOList = employeeService.getEmployeeBonus(date);
        return ResponseEntity.ok(bonusDTOList);
    }
}
