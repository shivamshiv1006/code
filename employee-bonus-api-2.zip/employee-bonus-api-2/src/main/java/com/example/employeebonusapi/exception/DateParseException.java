package com.example.employeebonusapi.exception;

public class DateParseException extends RuntimeException {

    public DateParseException(String message, Throwable cause) {
        super(message, cause);
    }
}
