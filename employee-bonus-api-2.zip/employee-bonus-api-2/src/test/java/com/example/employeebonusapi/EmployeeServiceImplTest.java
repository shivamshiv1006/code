package com.example.employeebonusapi;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.employeebonusapi.dto.EmployeeBonusDTO;
import com.example.employeebonusapi.entity.Employee;
import com.example.employeebonusapi.repository.EmployeeRepository;
import com.example.employeebonusapi.service.EmployeeServiceImpl;

@ExtendWith(MockitoExtension.class)
public class EmployeeServiceImplTest {

    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private EmployeeServiceImpl employeeService;

    @Test
    public void saveEmployees_ValidEmployee_Success() {
        // Arrange
        Employee employee = new Employee();
        List<Employee> employeeList = Arrays.asList(employee);
        when(employeeRepository.saveAll(anyIterable())).thenReturn(employeeList);

        // Act
        employeeService.saveEmployees(employeeList);

        // Assert
        verify(employeeRepository, times(1)).saveAll(employeeList);
    }

    @Test
    public void getEmployeeBonus_ValidDate_EmployeeBonusDTOList() {
        // Arrange
        String date = "Jan-01-2023";
        List<Employee> employees = Arrays.asList(
                new Employee(null, "John", "HR", 1000, "USD", "Dec-01-2022", "Feb-01-2023"),
                new Employee(null, "Alice", "Finance", 1500, "EUR", "Nov-01-2022", "Jan-01-2023")
        );
        when(employeeRepository.findAll()).thenReturn(employees);

        // Act
        List<EmployeeBonusDTO> bonusDTOList = employeeService.getEmployeeBonus(date);

        // Assert
        assertNotNull(bonusDTOList);
        assertEquals(2, bonusDTOList.size());
        
        // Assert INR currency data
        EmployeeBonusDTO inrBonus = bonusDTOList.get(0);
        assertEquals("INR", inrBonus.getCurrency());
        assertEquals(0, inrBonus.getEmployees().size()); // Assuming no employees with INR currency for the provided date
        
        // Assert USD currency data
        EmployeeBonusDTO usdBonus = bonusDTOList.get(1);
        assertEquals("USD", usdBonus.getCurrency());
        assertEquals(1, usdBonus.getEmployees().size());
        assertEquals("John", usdBonus.getEmployees().get(0).getEmpName());
        assertEquals(1000, usdBonus.getEmployees().get(0).getAmount());
    }
}
