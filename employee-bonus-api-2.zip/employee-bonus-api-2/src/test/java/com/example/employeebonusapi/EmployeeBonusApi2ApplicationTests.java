package com.example.employeebonusapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeBonusApi2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
